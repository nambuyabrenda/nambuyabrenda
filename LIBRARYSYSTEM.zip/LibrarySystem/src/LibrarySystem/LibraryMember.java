package LibrarySystem;

public class LibraryMember {
	private final int memberID = 0;
    private String name;
    private String contactInfo;
    // Implementation for member methods
	public int getMemberID() {
		return memberID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContactInfo() {
		return contactInfo;
	}
	public void setContactInfo(String contactInfo) {
		this.contactInfo = contactInfo;
	}
}
