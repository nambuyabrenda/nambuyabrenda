package LibrarySystem.util;

import java.util.ArrayList;
import java.util.Date;

public class LibrarySystem {
    // Implementation for system initialization, authentication, and program execution
}

public class LibraryMember {
    private int memberID;
    private String name;
    private String contactInfo;
    // Implementation for member methods
}

public class Book {
    private int bookID;
    private String title;
    private String author;
    private String genre;
    private boolean availability;
    // Implementation for book methods
}

public class Staff {
    private int staffID;
    private String name;
    private String role;
    // Implementation for staff methods
}

public class Catalog {
    private ArrayList<Book> books;
    // Implementation for catalog methods
}

public class Transaction {
    private int transactionID;
    private Book book;
    private LibraryMember member;
    private String transactionType;
    private Date transactionDate;
    // Implementation for transaction methods
}

